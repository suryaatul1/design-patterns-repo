package factory.com;

public abstract class Account {

}
