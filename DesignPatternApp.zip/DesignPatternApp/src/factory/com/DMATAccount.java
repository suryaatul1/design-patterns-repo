package factory.com;

public class DMATAccount {

}
