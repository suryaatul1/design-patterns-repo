package factory.com;

public interface BusinessAccount {

}
