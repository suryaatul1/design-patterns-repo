package bridge.com;

public class UPI implements Payment {

	@Override
	public double limit() {
		// TODO Auto-generated method stub
		return 300000;
	}

}
