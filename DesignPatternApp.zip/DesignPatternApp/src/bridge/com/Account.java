package bridge.com;

public abstract class Account {
	public Payment payment;
	
	public Account(Payment payment) {
		this.payment =payment;
	}
     public abstract void displayLimit();
}
