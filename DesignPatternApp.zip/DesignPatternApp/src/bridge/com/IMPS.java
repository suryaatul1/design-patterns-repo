package bridge.com;

public class IMPS implements Payment {

	@Override
	public double limit() {
		// TODO Auto-generated method stub
		return 100000;
	}

}
