package bridge.com;

public class Controller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account savingsAcct = new Savings(new IMPS());
		savingsAcct.displayLimit();
		
		Account currentAcct = new Savings(new UPI());
		currentAcct.displayLimit();

	}

}
