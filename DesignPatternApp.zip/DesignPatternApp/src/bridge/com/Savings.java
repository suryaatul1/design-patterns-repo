package bridge.com;

public class Savings extends Account {

	public Savings(Payment payment) {
		super(payment);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void displayLimit() {
		// TODO Auto-generated method stub
		System.out.println("the payment limit is " + payment.limit());
	}

}
