package bridge.com;

public class NEFT implements Payment{

	@Override
	public double limit() {
		// TODO Auto-generated method stub
		return 200000;
	}

}
