package bridge.com;

public interface Payment {
	double limit();

}
