package decorator.com;

public interface CreditCard {
	void features();
	double getLimit();

}
