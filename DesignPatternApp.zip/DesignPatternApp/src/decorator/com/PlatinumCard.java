package decorator.com;

public class PlatinumCard extends CreditCardDecorator{

	public PlatinumCard(CreditCard creditCard) {
		super(creditCard);
		// TODO Auto-generated constructor stub
	}

	public void features() {
		super.features();
		double limit = super.getLimit()+150000;
		System.out.println("The extended limit for Silver is "+ limit);
	}

}
