package decorator.com;

public class CreditCardDecorator implements CreditCard {
     CreditCard creditCard;
 
     
	public CreditCardDecorator(CreditCard creditCard) {
		super();
		this.creditCard = creditCard;
	}


	@Override
	public void features() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public double getLimit() {
		// TODO Auto-generated method stub
		return  creditCard.getLimit();
	}

}
