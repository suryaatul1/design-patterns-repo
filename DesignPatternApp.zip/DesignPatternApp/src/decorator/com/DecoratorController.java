package decorator.com;

public class DecoratorController {
	
	public static void main(String[] args) {
	CreditCardDecorator  decorator = new CreditCardDecorator(new BasicCard());
	decorator.features();
	CreditCardDecorator silver = new SilverCard(new BasicCard());
	silver.features();
	CreditCardDecorator gold = new GoldCard(new BasicCard());
	gold.features();
	CreditCardDecorator platinum = new PlatinumCard(new BasicCard());
	platinum.features();
	
	}

}
