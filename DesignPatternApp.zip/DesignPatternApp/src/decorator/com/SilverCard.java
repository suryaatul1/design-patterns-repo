package decorator.com;

public class SilverCard extends CreditCardDecorator{

	public SilverCard(CreditCard creditCard) {
		super(creditCard);
		// TODO Auto-generated constructor stub
	}

	public void features() {
		super.features();
		double limit = super.getLimit()+50000;
		System.out.println("The extended limit for Silver is "+ limit);
	}
}
