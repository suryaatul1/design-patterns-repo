package decorator.com;

public class BasicCard implements CreditCard {
	
	private double limit ;
	
	public BasicCard(double limit) {
		this.limit=limit;
	}
	public BasicCard() {
		this.limit = 50000;
	}

	@Override
	public void features() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public double getLimit() {
		// TODO Auto-generated method stub
		return limit;
	}

}
