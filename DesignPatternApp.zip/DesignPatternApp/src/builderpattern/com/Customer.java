package builderpattern.com;

public class Customer {
	private Integer id;
	private String name;
	private String username;
	private String password;
	private String email;
	private String contact;
	private String address;
	
	private Customer(CustomerBuilder builder) {
		this.id = builder.id;
		this.name = builder.name;
		this.username = builder.username;
		this.password = builder.password;
		this.email = builder.email;
		this.contact =  builder.contact;
		this.address = builder.address;
	}
	
	public static class CustomerBuilder{
		private Integer id;
		private String name;
		private String username;
		private String password;
		private String email;
		private String contact;
		private String address;
		
		public CustomerBuilder(String name, String username, String password){
			super();
			this.name = name;
			this.username = username;
			this.password = password;
		}
		
		public CustomerBuilder setId(Integer id) {
			this.id = id;
			return this;
		}
		public CustomerBuilder setContact(String contact) {
			this.contact = contact;
			return this;
		}
		public CustomerBuilder setEmail(String email) {
			this.email = email;
			return this;
		}
		public CustomerBuilder setAddress(String address) {
			this.address = address;
			return this;
		}
		
		public Customer build() {
			return new Customer(this);
		}
	}
   
	public Integer getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}
	public String getEmail() {
		return email;
	}

	public String getContact() {
		return contact;
	}

	public String getAddress() {
		return address;
	}



	

}
