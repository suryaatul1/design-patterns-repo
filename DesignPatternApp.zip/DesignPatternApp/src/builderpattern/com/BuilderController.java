package builderpattern.com;

public class BuilderController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer = new Customer.CustomerBuilder("Harry", "sdty", "6464647").setContact("45675678").build();
		System.out.println(customer.getContact());
		Customer customer1 = new Customer.CustomerBuilder("Harry", "sdty", "6464647").setAddress("Mumbai").build();
		System.out.println(customer1.getAddress());
		
	}

}
