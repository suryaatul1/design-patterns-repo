package adapter.com;

public class NEFTTrasaction extends Transaction{

                                         
	public NEFTTrasaction(String fromAccount, String toAccount, double amount) {
		super(fromAccount, toAccount, amount);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getFromAccount() {
		// TODO Auto-generated method stub
		return fromAccount;
	}

	@Override
	public String getToAccount() {
		// TODO Auto-generated method stub
		return toAccount;
	}

	@Override
	public double getAmount() {
		// TODO Auto-generated method stub
		return amount;
	}

	@Override
	void process() {
		// TODO Auto-generated method stub
		System.out.println("process Details "+ fromAccount +"  " + toAccount + " " + amount);
		
	}
	

}
