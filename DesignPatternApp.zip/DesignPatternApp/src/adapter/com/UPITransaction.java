package adapter.com;

public class UPITransaction extends Transaction {

	public UPITransaction(String fromContact, String toContact, double amount, UpiAdapter adapter) {
		super(adapter.convertToAmount(fromContact),adapter.convertToAmount(toContact), amount);
		
		//adapter = this
		// TODO Auto-generated constructor stub
	}

	@Override
	String getFromAccount() {
		// TODO Auto-generated method stub
		return fromAccount;
	}

	@Override
	public String getToAccount() {
		// TODO Auto-generated method stub
		return toAccount;
	}

	@Override
	public double getAmount() {
		// TODO Auto-generated method stub
		return amount;
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub
		System.out.println("process Details "+ fromAccount +"  " + toAccount + " " + amount);
		
	}

}
