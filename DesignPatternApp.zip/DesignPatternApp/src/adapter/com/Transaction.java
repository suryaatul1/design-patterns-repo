package adapter.com;

public abstract class Transaction {
	String fromAccount;
	String toAccount;
	double amount;
	
	public Transaction(String fromAccount, String toAccount, double amount) {
		super();
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
	}

	abstract String getFromAccount();
	abstract String getToAccount();
	abstract double getAmount() ;
	abstract void process();

}
