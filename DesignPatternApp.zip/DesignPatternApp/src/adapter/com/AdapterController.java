package adapter.com;

public class AdapterController {
	
	public static void main(String[] args) {
		Transaction neft = new NEFTTrasaction("ACCT55676", "ACCT55676", 34000);
		neft.process();
		Transaction upi = new UPITransaction("8869709686", "8869709600", 20000, 
				new UpiAdapter("8869709686", "8869709600", 20000));
		upi.process();
		
	}
}
