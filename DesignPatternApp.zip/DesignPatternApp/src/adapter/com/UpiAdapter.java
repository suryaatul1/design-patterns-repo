package adapter.com;

import java.util.HashMap;
import java.util.Map;

public class UpiAdapter {
	private String fromContact;
	private String toContact;
	private double amount;
	private Map<String,String > map;

	
	public UpiAdapter(String fromContact, String toContact, double amount) {
		super();
		this.fromContact = fromContact;
		this.toContact = toContact;
		this.amount = amount;
	}
	
	{
		map = new HashMap<>();
		map.put("8869709686", "ACCT55676");
		map.put("8869709600", "ACCT55676");
		map.put("78997897", "AC10101012");
		map.put("78997896", "AC10101013");
	}
	
	public String convertToAmount(String contact) {
		if(map.containsKey(contact))
			return map.get(contact);
		return null;
		
	}

	public String getFromContact() {
		return fromContact;
	}
	public String getToContact() {
		return toContact;
	}
	public double getAmount() {
		return amount;
	}


}
