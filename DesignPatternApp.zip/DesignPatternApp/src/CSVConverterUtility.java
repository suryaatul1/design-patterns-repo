
public class CSVConverterUtility {
	
	static CSVConverterUtility  utility ;
	
   private CSVConverterUtility() {
	   
   }
   
   public static CSVConverterUtility getInstance() {
	   if (utility == null)
		   utility = new CSVConverterUtility()  ;
	   return utility;
   }
 
   public Customer ConvertCSVTexttoCustomerObject(String input){
	   
	   String[] sarry = input.split(",");
	   Customer in = new Customer();
	   in.setCity(sarry[2]);
	   in.setId(Integer.parseInt(sarry[0]));
	   in.setName(sarry[1].trim());
	   in.setPan(sarry[3]);
	   in.setContact(sarry[4]);
	   
	   return in;
	   
   }
}
