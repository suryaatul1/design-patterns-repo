
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "1, harry, Delhi, uhsdhs, 22726212";
		
		Customer customer = CSVConverterUtility.getInstance().ConvertCSVTexttoCustomerObject(input);
		System.out.println(customer);
		System.out.println(CSVConverterUtility.getInstance());
		System.out.println(CSVConverterUtility.getInstance().ConvertCSVTexttoCustomerObject("2, suman, Mumbai, sjdskjds, 56756778"));

	}

}
