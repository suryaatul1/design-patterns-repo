package com.enums;

public enum AccountType {
        SAVINGS,DMAT,CHECKINGS
}
