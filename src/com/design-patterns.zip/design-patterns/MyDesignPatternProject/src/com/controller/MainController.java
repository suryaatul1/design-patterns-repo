package com.controller;
import com.model.Customer;

public class MainController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// Creting object using  traditional setters
		Customer cl1  =  new Customer();
		cl1.setId(2);
		cl1.setName("hari");
		cl1.setCity("mumbai");
		cl1.setContact("82782743");

		
		//Creating object using pipe technique
		Customer cl2 =  (Customer) new Customer().setId(3).setName("keerthi").setCity("chennai").setContact("38726273");
				
		
		//Creating object using Constructor
		Customer cl3 =  new Customer(4, "neeraj", "kolkata", "48774444");
		
		Customer.setRateOfInterest(4.0);
		
		System.out.println(cl1);
		System.out.println(cl2);
		System.out.println(cl3);
		System.gc();
		
		Customer.setRateOfInterest(5.0);
		
		Customer.Address cl = new Customer.Address().setCity("vizag").setPincode("677867");
		Customer.User      u1 = new Customer.User().setPassword("dshdj").setUsername("fhdhfd").setRole("Owner");
		
		
		System.out.println(cl);
		System.out.println(u1);
		
	}

}
