package com.controller;

import com.utility.StringUtility;

public class CSVController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			String csv  = "1,jyothi,shjhsd,sd,jshdshd";
			System.out.println("CustoomeController " + StringUtility.getInputCSV(csv));

	}

}
