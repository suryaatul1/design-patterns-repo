package com.controller;

import com.utility.StringUtility;

public class CustomerController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String csv  = "1,harry,shjhsd,sd,jshdshd";
		System.out.println("CustoomeController " + StringUtility.getInputCSV(csv));
	}

}
