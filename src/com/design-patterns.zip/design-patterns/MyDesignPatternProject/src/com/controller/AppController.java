package com.controller;

import com.enums.AccountType;
import com.model.AccountHolder;

public class AppController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccountHolder acct =  new AccountHolder();
		acct.setAccountNumber("ds3232323");
		acct.setAccType(AccountType.SAVINGS);
		
		System.out.println(acct);
		
		for(AccountType acc: AccountType.values()) {
			System.out.println(acc);
		}
		
		acct.setAccType(AccountType.valueOf("DMAT"));
		System.out.println(acct);

	}

}
