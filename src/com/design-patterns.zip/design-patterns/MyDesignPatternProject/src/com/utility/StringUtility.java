package com.utility;

public class StringUtility {

	
private StringUtility(){}

public static String getInputCSV(String input) {
	String[] arr = input.split(",");
	return arr[1];
}

}
