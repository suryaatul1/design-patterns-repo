package com.model;

public class Customer {
	
	private int id;
	private String name;
	private String city;
	private String contact;
	private static double rateOfInterest;
	
	
	public Customer() {
		
	}
	
	public Customer(int id, String name, String city, String contact) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.contact = contact;
		
	}
	public static class Address{
		private String city;
		private String pincode;
		public String getCity() {
			return city;
		}
		public Address setCity(String city) {
			this.city = city;
			return this;
		}
		public String getPincode() {
			return pincode;
		}
		public Address setPincode(String pincode) {
			this.pincode = pincode;
			return this;
		}
		@Override
		public String toString() {
			return "Address [city=" + city + ", pincode=" + pincode + "]";
		}
		
		
	}
	
	public static class User {
		private String username;
		private String password;
		private String role;
		public String getUsername() {
			return username;
		}
		public User setUsername(String username) {
			this.username = username;
			return this;
		}
		public String getPassword() {
			return password;
		}
		public User setPassword(String password) {
			this.password = password;
			return this;
		}
		public String getRole() {
			return role;
		}
		public User setRole(String role) {
			this.role = role;
			return this;
		}
		@Override
		public String toString() {
			return "User [username=" + username + ", password=" + password + ", role=" + role + "]";
		}
		
	}
	public int getId() {
		return id;
	}
	public Customer setId(int id) {
		this.id = id;
		return this;
	}
	public String getName() {
		return name;
	}
	public Customer setName(String name) {
		this.name = name;
		return this;
	}
	public String getCity() {
		return city;
	}
	public Customer setCity(String city) {
		this.city = city;
		return this;
	}
	public String getContact() {
		return contact;
	}
	public Customer setContact(String contact) {
		this.contact = contact;
		return this;
	}

	public static double getRateOfInterest() {
		return rateOfInterest;
	}

	public static void setRateOfInterest(double rateOfInterest) {
		Customer.rateOfInterest = rateOfInterest;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", city=" + city + ", contact=" + contact + "]";
	}



}
