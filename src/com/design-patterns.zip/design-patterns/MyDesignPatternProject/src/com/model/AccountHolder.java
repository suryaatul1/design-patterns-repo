package com.model;

import com.enums.AccountType;

public class AccountHolder {
        private String accountNumber;
        private AccountType accType;
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public AccountType getAccType() {
			return accType;
		}
		public void setAccType(AccountType accType) {
			this.accType = accType;
		}
		@Override
		public String toString() {
			return "AccountHolder [accountNumber=" + accountNumber + ", accType=" + accType + "]";
		}
        
        
}
